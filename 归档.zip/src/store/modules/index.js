// 导入用户模块
import user from './user'

export default {
  user
}
