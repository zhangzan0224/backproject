export default {
  // 二三级菜单
  secondAndThirdMenu: JSON.parse(localStorage.getItem('secondandthree')) || [],
  //  后端返回的路由信息
  menu: []
};
