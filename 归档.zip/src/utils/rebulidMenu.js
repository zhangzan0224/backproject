import Layout from '@/views/Layout';
// 将后台返回的路由数据得重新处理下
export const rebulidMenu = (arr) => {
  if (!arr.length) return [];
  arr.forEach((element) => {
    if (element?.component === 'Layout') {
      element.component = Layout;
    } else {
      // console.log('2');
      element.component = setComponetValue(element.component);
    }
    if (element.children?.length) {
      rebulidMenu(element.children);
    }
  });
  console.log('@', arr);
  return arr;
};

// function setComponetValue (val) {
//   console.log('@/views/' + val);
//   return () => import('@/views/' + val);
// }
// 使用require的方式
function setComponetValue (path) {
  // console.log(path);
  return (resolve) => require([`@/views/${path}`], resolve);
}
