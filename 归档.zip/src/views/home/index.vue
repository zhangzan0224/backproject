<template>
  <div class="home">
    Home组件
    <p>aaaa</p>
  </div>
</template>

<script>
export default {
  name: 'Home',
  mounted () {}
}
</script>

<style lang="scss" scoped>
p {
  color: $RED;
}
</style>
