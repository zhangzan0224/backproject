<template>
  <div class="">
    部门管理
  </div>
</template>
<script>
export default {
  name: '',
  components: {},
  data () {
    return {};
  },
  // 计算属性
  computed: {},
  watch: {},
  mounted () {},
  methods: {}
};
</script>
<style lang="scss" scoped></style>
