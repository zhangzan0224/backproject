<template>
  <div class="user">
    <left-tree />
    <right-table />
  </div>
</template>
<script>
import leftTree from '@/views/sytem/user/leftTree';
import rightTable from '@/views/sytem/user/rightTable';

export default {
  name: 'User',
  components: { leftTree, rightTable },
  data () {
    return {};
  },
  // 计算属性
  computed: {},
  watch: {},
  mounted () {},
  methods: {}
};
</script>
<style lang="scss" scoped>
.user {
  height: 100%;
}
</style>
